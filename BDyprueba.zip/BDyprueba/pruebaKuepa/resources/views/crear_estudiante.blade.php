@extends("menu")
@section("titulo", "Registrar nivel")
@section("contenido")
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <form method="POST" action="{{route('estudiante.store')}}">
            @csrf
           
                <div class="form-group">
                    <input required autocomplete="off" name="name" class="form-control" type="text" placeholder="Nombre">
                </div>
                <div class="form-group">
                    <input required autocomplete="off" name="apellidos" class="form-control" type="text" placeholder="Apellidos">
                </div>
                <div class="form-group">
                    <input required autocomplete="off" name="email" class="form-control" type="email" placeholder="Correo electrónico">
                </div>
                <div class="form-group">
                    <input required autocomplete="off" maxlength="10" name="telefono" class="form-control" type="number" placeholder="Número de telefono actualizado">
                </div>
                <div class="form-group">
                   <select class="form-group" name="programa" id="programa">
                       <option value=""  selected="selected" disabled="disabled">Seleccione un programa de su interes</option>
                       <option value="Bachillerato">Bachillerato</option>
                       <option value="Inglés">Inglés</option>
                       <option value="Preicfes">Preicfes</option>
                   </select>
                </div>
                <button class="btn btn-success">Guardar</button>
               
            </form>
        </div>
        <div class="col-md-4"></div>
    </div>
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    </div>
    <div class="col-md-4"></div>
    </div>
   
@endsection