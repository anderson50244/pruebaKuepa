@extends("menu")
@section("titulo", "Registrar nivel")
@section("contenido")
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
           <table class="table table-bordered">
           <thead>
               <tr>
                   <th>Nombre</th>
                   <th>Apellidos</th>
                   <th>Email</th>
                   <th>Teléfono</th>
                   <th>Programa</th>
                   <th colspan='2' class="text-center">Marcar como contactado</th>
               </tr>
</thead>
               @foreach($estudiantes as $estudiante)
                    @if($estudiante->estado!='llamado')
                    <tr>
                        <td>{{$estudiante->name}}</td>
                        <td>{{$estudiante->apellidos}}</td>
                        <td>{{$estudiante->email}}</td>
                        <td>{{$estudiante->telefono}}</td>
                        <td>{{$estudiante->programa}}</td>
                        <form method="POST" id="miForm{{$estudiante->id}}"  action="{{route('estudiante.update',$estudiante->id)}}">
                        @method("PUT")
                        @csrf
                        <td align='center'><input type="checkbox" name="email{{$estudiante->id}}" id="{{$estudiante->id}}" onChange="cambiar_estado({{$estudiante->id}})" value="{{$estudiante->email}}"></td>

                        </form>
                      
                    </tr>
                    @endif
               @endforeach
           </table>
        </div>
        <div class="col-md-2"></div>
    </div>
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    </div>
    <div class="col-md-4"></div>
    </div>
   
@endsection

<script>

    function cambiar_estado(form){

        document.getElementById("miForm"+form).submit();
    }
</script>