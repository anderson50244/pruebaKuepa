<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Estudiante;

class EstudianteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $estudiantes = Estudiante::all();
        return view('ver_estudiantes')->with('estudiantes',$estudiantes);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('crear_estudiante');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   

        if (Estudiante::where('email', '=', $request->input('email'))->count() > 0) {
            
            $estudi = Estudiante::where("email","=",$request->input('email'))->get()->toArray();
            $estudiante = Estudiante::findOrFail($estudi[0]['id']);
            
            $estudiante->name = $request->name;
            $estudiante->apellidos = $request->apellidos;
            $estudiante->email = $request->email;
            $estudiante->telefono = $request->telefono;
            $estudiante->programa = $request->programa;
            $estudiante->estado='No llamado';
            $estudiante->save();
            return redirect()->route("estudiante.create")->with("success","Estudiante registrado con exito");
        }else{

            $estudiante = new Estudiante($request->input());
            $estudiante->saveOrFail();
            return redirect()->route("estudiante.create")->with("success","Estudiante registrado con exito");
        }
       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
        $estudiante = Estudiante::findOrFail($id);
        
        $estudiante->estado='llamado';
        $estudiante->save();

        $estudian= Estudiante::all();
        return view('ver_estudiantes')->with('estudiantes',$estudian);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
