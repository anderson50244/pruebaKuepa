<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="../css/app.css">

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"></a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="<?php echo e(route('estudiante.create')); ?>"><b>Registrar estudiante</b></a></li>
      <li>&nbsp;</li>
      <li><a href="<?php echo e(route('estudiante.index')); ?>"><b>Contactar estudiantes</b> </a></li>
    </ul>
  </div>
  <?php echo $__env->yieldContent("contenido"); ?>
</nav><?php /**PATH C:\xampp\htdocs\pruebaKuepa\resources\views/menu.blade.php ENDPATH**/ ?>