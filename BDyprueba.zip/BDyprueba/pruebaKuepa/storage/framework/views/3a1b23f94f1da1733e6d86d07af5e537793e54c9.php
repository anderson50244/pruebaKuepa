
<?php $__env->startSection("titulo", "Registrar nivel"); ?>
<?php $__env->startSection("contenido"); ?>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
           <table class="table table-bordered">
           <thead>
               <tr>
                   <th>Nombre</th>
                   <th>Apellidos</th>
                   <th>Email</th>
                   <th>Teléfono</th>
                   <th>Programa</th>
                   <th colspan='2' class="text-center">Marcar como contactado</th>
               </tr>
</thead>
               <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($estudiante->estado!='llamado'): ?>
                    <tr>
                        <td><?php echo e($estudiante->name); ?></td>
                        <td><?php echo e($estudiante->apellidos); ?></td>
                        <td><?php echo e($estudiante->email); ?></td>
                        <td><?php echo e($estudiante->telefono); ?></td>
                        <td><?php echo e($estudiante->programa); ?></td>
                        <form method="POST" id="miForm<?php echo e($estudiante->id); ?>"  action="<?php echo e(route('estudiante.update',$estudiante->id)); ?>">
                        <?php echo method_field("PUT"); ?>
                        <?php echo csrf_field(); ?>
                        <td align='center'><input type="checkbox" name="email<?php echo e($estudiante->id); ?>" id="<?php echo e($estudiante->id); ?>" onChange="cambiar_estado(<?php echo e($estudiante->id); ?>)" value="<?php echo e($estudiante->email); ?>"></td>

                        </form>
                      
                    </tr>
                    <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </table>
        </div>
        <div class="col-md-2"></div>
    </div>
    <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4">
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    </div>
    <div class="col-md-4"></div>
    </div>
   
<?php $__env->stopSection(); ?>

<script>

    function cambiar_estado(form){

        document.getElementById("miForm"+form).submit();
    }
</script>
<?php echo $__env->make("menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pruebaKuepa\resources\views/ver_estudiantes.blade.php ENDPATH**/ ?>